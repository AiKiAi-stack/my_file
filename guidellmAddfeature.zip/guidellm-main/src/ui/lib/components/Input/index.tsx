export { Component as Input } from './Input.component';
export type { InputProps } from './Input.interfaces';
