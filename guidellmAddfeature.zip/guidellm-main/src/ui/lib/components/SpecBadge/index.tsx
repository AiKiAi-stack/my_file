export { Component as SpecBadge } from './SpecBadge.component';
export type { SpecBadgeProps } from './SpecBadge.interfaces';
