export { Component as MeanMetricSummary } from './MeanMetricSummary.component';
export type { MeanMetricSummaryProps } from './MeanMetricSummary.interfaces';
