export { Component as Badge } from './Badge.component';
export type { BadgeProps } from './Badge.interfaces';
