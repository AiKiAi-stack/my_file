export { Component as WorkloadDetails } from './WorkloadDetails.component';
