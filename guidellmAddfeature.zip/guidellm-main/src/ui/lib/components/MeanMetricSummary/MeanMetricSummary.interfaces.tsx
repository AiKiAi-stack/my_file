export interface MeanMetricSummaryProps {
  meanValue: string;
  meanUnit: string;
  rpsValue: number;
}
