export type HeaderCellProps = {
  withDivider?: boolean;
};
