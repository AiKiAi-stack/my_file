export { Component as WorkloadMetrics } from './WorkloadMetrics.component';
