export interface CarouselProps {
  label: string;
  items: string[];
}
