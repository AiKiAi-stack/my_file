export { Component as GraphTitle } from './GraphTitle.component';
export type { GraphTitleProps } from './GraphTitle.interfaces';
