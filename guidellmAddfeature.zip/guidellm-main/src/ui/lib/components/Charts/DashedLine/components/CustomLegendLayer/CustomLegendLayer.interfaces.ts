import { CustomLayerProps } from '@nivo/line';

export interface CustomLegendLayerProps extends CustomLayerProps {
  height?: number;
}
