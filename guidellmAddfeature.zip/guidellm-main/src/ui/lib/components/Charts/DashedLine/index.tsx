export { Component as DashedLine } from './DashedLine.component';
export type { DashedLineProps } from './DashedLine.interfaces';
