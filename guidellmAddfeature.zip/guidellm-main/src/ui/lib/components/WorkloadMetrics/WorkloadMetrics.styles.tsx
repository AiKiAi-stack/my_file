import { styled } from '@mui/material';

export const GraphsWrapper = styled('div')({
  width: '540px',
  height: '288px',
});
