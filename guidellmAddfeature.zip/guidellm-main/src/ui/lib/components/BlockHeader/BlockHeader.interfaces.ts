export interface BlockHeaderProps {
  label: string;
  withDivider?: boolean;
}
