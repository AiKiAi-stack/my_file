export { Component as DistributionPercentiles } from './DistributionPercentiles.component';
export type {
  PercentileItem,
  DistributionPercentilesProps,
} from './DistributionPercentiles.interfaces';
