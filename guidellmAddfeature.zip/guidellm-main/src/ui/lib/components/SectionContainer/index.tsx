export { Component as SectionContainer } from './SectionContainer.component';
export type { SectionContainerProps } from './SectionContainer.interfaces';
