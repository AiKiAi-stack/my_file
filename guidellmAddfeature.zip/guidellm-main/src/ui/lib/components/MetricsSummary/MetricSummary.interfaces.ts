export type CustomSelectProps = {
  placeholder?: string;
};
