export { Component as PageHeader } from './PageHeader.component';
