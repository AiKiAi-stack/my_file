import { Benchmarks, Name } from './benchmarks.interfaces';

export const name: Readonly<Name> = 'benchmarks';

export const initialState: Benchmarks = [];
