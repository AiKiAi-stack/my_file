export { Component as DataPanel } from './DataPanel.component';
export type { DataPanelProps } from './DataPanel.interfaces';
