export { Component as MetricValue } from './MetricValue.component';
export type { MetricValueProps } from './MetricValue.interfaces';
