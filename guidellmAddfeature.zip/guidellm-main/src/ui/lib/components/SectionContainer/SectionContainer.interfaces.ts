import { ReactElement } from 'react';

export interface SectionContainerProps {
  children: ReactElement;
}
