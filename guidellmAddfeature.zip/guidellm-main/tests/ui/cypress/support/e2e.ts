// Add custom support logic here if needed in future.
// Currently minimal, as no global behavior is required.
