import { ReactNode } from 'react';

export interface RowContainerProps {
  label: string;
  children: ReactNode;
}
