import { RootState } from '../../index';

export const selectSloState = (state: RootState) => state.slo;
