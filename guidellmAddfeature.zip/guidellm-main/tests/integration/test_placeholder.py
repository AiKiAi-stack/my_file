import pytest


@pytest.mark.smoke
def test_placeholder():
    assert True
