export { Component as PageFooter } from './PageFooter.component';
