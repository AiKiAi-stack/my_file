export const runInfoScript = `window.runInfo = {
  "model": {
    "name": "neuralmagic/Qwen2.5-7B-quantized.w8a8",
    "size": 0
  },
  "task": "N/A",
  "dataset": {
    "name": "N/A"
  },
  "timestamp": 1744310555.0286171
};`;
