export const ResponsiveLine = () => null;
