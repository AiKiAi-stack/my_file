export { Component as MiniCombined } from './MiniCombined.component';
export type {
  MiniCombinedProps,
  MiniCombinedWithResizeProps,
} from './MiniCombined.interfaces';
