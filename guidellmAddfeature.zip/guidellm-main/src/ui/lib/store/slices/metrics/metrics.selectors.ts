import { RootState } from '../../index';

export const selectMetricsState = (state: RootState) => state.metrics;
