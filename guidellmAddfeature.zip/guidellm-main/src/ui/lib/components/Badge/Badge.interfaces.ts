export interface BadgeProps {
  label: string;
}
