export { Component as BlockHeader } from './BlockHeader.component';
export type { BlockHeaderProps } from './BlockHeader.interfaces';
