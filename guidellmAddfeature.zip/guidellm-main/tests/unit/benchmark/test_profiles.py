from guidellm.benchmark.profiles import SweepProfile
from guidellm.scheduler import SynchronousStrategy


def test_sweep_profile_splits_strategy_constraints():
    profile_kwargs = SweepProfile.resolve_args(
        rate_type="sweep",
        rate=[5],
        random_seed=123,
        constraints={
            "max_requests": [10, 20, 30],
            "max_seconds": 15,
        },
        sweep_size=3,
    )

    profile = SweepProfile(**profile_kwargs)

    assert profile.constraints == {"max_seconds": 15}
    assert profile.strategy_constraints == {"max_requests": [10, 20, 30]}


def test_sweep_profile_next_strategy_constraints_apply_in_order():
    profile = SweepProfile(
        sweep_size=3,
        strategy_constraints={"max_requests": [5, 10, None]},
        constraints={"max_seconds": 30},
    )

    strategy = SynchronousStrategy()

    first_constraints = profile.next_strategy_constraints(strategy, None, None)
    assert first_constraints is not None
    assert "max_requests" in first_constraints
    assert first_constraints["max_requests"].max_num == 5
    assert "max_seconds" in first_constraints

    profile.completed_strategies.append(strategy)

    second_constraints = profile.next_strategy_constraints(strategy, None, None)
    assert second_constraints is not None
    assert "max_requests" in second_constraints
    assert second_constraints["max_requests"].max_num == 10

    profile.completed_strategies.append(strategy)

    third_constraints = profile.next_strategy_constraints(strategy, None, None)
    assert third_constraints is not None
    assert "max_requests" not in third_constraints
    assert "max_seconds" in third_constraints

