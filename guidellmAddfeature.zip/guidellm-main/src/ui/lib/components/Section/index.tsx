export { Component as Section } from './Section.component';
export type { SectionProps } from './Section.interfaces';
