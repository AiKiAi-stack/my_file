export { Component as Combined } from './Combined.component';
export type { CombinedProps } from './Combined.interfaces';
