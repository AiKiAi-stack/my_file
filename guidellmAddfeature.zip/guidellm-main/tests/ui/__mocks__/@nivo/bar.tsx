export const ResponsiveBar = () => null;
export const BarCustomLayerProps = () => null;
