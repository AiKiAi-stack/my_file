export { Component as Carousel } from './Carousel.component';
export type { CarouselProps } from './Carousel.interfaces';
