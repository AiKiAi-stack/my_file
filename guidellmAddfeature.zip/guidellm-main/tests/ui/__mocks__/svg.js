const svgMock = 'svg';
export default svgMock;
export const ReactComponent = 'div';
//This was from svgr docs: https://react-svgr.com/docs/jest/
