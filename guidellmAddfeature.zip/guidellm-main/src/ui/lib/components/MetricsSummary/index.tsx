export { Component as MetricsSummary } from './MetricsSummary.component';
