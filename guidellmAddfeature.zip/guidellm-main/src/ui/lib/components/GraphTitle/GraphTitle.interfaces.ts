export interface GraphTitleProps {
  title: string;
}
