import { LinesSeries } from '../../../common/interfaces';

export interface CustomLegendLayerProps {
  series: LinesSeries[];
  height: number;
}
