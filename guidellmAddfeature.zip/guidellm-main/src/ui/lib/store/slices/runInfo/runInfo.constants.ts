import { Name } from './runInfo.interfaces';

export const name: Readonly<Name> = 'runInfo';
