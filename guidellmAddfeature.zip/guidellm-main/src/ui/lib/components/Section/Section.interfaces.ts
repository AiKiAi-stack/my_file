export interface SectionProps {
  label: string;
  value: string;
}
